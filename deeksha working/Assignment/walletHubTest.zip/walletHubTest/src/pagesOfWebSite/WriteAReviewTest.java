package pagesOfWebSite;
import supportProviderUtilities.CommonMeths;
import supportProviderUtilities.ConstantsDeclared;

public class WriteAReviewTest {
	public static void writehealthreview()throws Exception
	{   CommonMeths.handlingClicks("drpdown");
	
		CommonMeths.handlingClicks("health");
		
		CommonMeths.handlingmousehoveringwithClick("overallRate");
		
		CommonMeths.handlingtextboxes("review", ConstantsDeclared.review);
		CommonMeths.handlingClicks("submit");
		
	}

}
