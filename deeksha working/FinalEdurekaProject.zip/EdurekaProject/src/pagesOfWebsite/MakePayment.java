package pagesOfWebsite;

import commonMethods.Commonmeths;

public class MakePayment {
	public static void EnterFirstName(String PropertyA, String testData) throws Exception {
		Commonmeths.handlingtextboxes(PropertyA, testData);
	}
	public static void EnterLastName(String PropertyA, String testData) throws Exception {
		Commonmeths.handlingtextboxes(PropertyA, testData);
	}
	public static void SelectMealPreference(String PropertyA, String testData) throws Exception {
		Commonmeths.handlingdropdowns(PropertyA, testData);
	}
	public static void SelectCardType(String PropertyA, String testData) throws Exception {
		Commonmeths.handlingdropdowns(PropertyA, testData);
	}
	public static void EnterCardNumber(String PropertyA, int testData) throws Exception {
		Commonmeths.handlingIntegertextboxes(PropertyA, testData);
	}
	public static void EnterExpiryMonth(String PropertyA, int testData) throws Exception {
		Commonmeths.handlingIntdropdowns(PropertyA, testData);
	}
	public static void EnterExpiryYear(String PropertyA, int testData) throws Exception {
		Commonmeths.handlingIntdropdowns(PropertyA, testData);
	}
	public static void EnterFirstNameonCard(String PropertyA, String testData) throws Exception {
		Commonmeths.handlingtextboxes(PropertyA, testData);
	}
	public static void EnterLastNameonCard(String PropertyA, String testData) throws Exception {
		Commonmeths.handlingtextboxes(PropertyA, testData);
	}
	public static void EnetrBillingAddress(String PropertyA, String testData) throws Exception {
		Commonmeths.handlingtextboxes(PropertyA, testData);
	}
	public static void EnterBillingCity(String PropertyA, String testData) throws Exception {
		Commonmeths.handlingtextboxes(PropertyA, testData);
	}
	public static void EnterBillingState(String PropertyA, String testData) throws Exception {
		Commonmeths.handlingtextboxes(PropertyA, testData);
	}
	public static void EnetrBillingPostalCode(String PropertyA, int testData) throws Exception {
		Commonmeths.handlingIntegertextboxes(PropertyA, testData);
	}
	public static void SelectBillingCountry(String PropertyA, String testData) throws Exception {
		Commonmeths.handlingdropdowns(PropertyA, testData);
	}
	public static void EnetrDeliveryAddress(String PropertyA, String testData) throws Exception {
		Commonmeths.handlingtextboxes(PropertyA, testData);
	}
	public static void EnterDeliveryCity(String PropertyA, String testData) throws Exception {
		Commonmeths.handlingtextboxes(PropertyA, testData);
	}
	public static void EnterDeliveryState(String PropertyA, String testData) throws Exception {
		Commonmeths.handlingtextboxes(PropertyA, testData);
	}
	public static void EnetrDeliveryPostalCode(String PropertyA, int testData) throws Exception {
		Commonmeths.handlingIntegertextboxes(PropertyA, testData);
	}
	public static void SelectDeliveryCountry(String PropertyA, String testData) throws Exception {
		Commonmeths.handlingdropdowns(PropertyA, testData);
	}
	public static void ClickOnSecurePurchase(String PropertyA) throws Exception {
		Commonmeths.handlingClicks(PropertyA);
	}


}
