package pagesOfWebsite;

import commonMethods.Commonmeths;

public class SelectFlight {

	public static void selectDepartFlight(String PropertyA)throws Exception
	{
		Commonmeths.handlingClicks(PropertyA);
	}
	public static void selectReturnFlight(String PropertyA)throws Exception
	{
		Commonmeths.handlingClicks(PropertyA);
	}
	public static void clickContinueFlight(String PropertyA)throws Exception
	{
		Commonmeths.handlingClicks(PropertyA);
	}
}
