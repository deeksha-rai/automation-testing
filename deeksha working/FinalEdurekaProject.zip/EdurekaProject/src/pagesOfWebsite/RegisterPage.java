package pagesOfWebsite;

import commonMethods.Commonmeths;

public class RegisterPage {
	public static void clickonRegister(String PropertyA)throws Exception
	{
		Commonmeths.handlingClicks(PropertyA);
	}

	public static void enterFirstName(String PropertyA,String testData)throws Exception
	{
		Commonmeths.handlingtextboxes(PropertyA, testData);	
	}
	public static void enterLastName(String PropertyA,String testData)throws Exception
	{
		Commonmeths.handlingtextboxes(PropertyA, testData);	
	}
	public static void enterPhone(String PropertyA,int testData)throws Exception
	{
		Commonmeths.handlingIntegertextboxes(PropertyA, testData);	
	}
	public static void enterEmail(String PropertyA,String testData)throws Exception
	{
		Commonmeths.handlingtextboxes(PropertyA, testData);	
	}
	public static void enterAddress(String PropertyA,String testData)throws Exception
	{
		Commonmeths.handlingtextboxes(PropertyA, testData);	
	}
	public static void enterCity(String PropertyA,String testData)throws Exception
	{
		Commonmeths.handlingtextboxes(PropertyA, testData);	
	}
	public static void enterState(String PropertyA,String testData)throws Exception
	{
		Commonmeths.handlingtextboxes(PropertyA, testData);	
	}
	public static void enterzipCode(String PropertyA,int testData)throws Exception
	{
		Commonmeths.handlingIntegertextboxes(PropertyA, testData);	
	}
	public static void enterCountry(String PropertyA,String testData)throws Exception
	{
		Commonmeths.handlingdropdowns(PropertyA, testData);	
	}
	public static void enterUserName(String PropertyA,String testData)throws Exception
	{
		Commonmeths.handlingtextboxes(PropertyA, testData);	
	}
	public static void enterPassword(String PropertyA,String testData)throws Exception
	{
		Commonmeths.handlingtextboxes(PropertyA, testData);	
	}
	public static void enterConfirmPassword(String PropertyA,String testData)throws Exception
	{
		Commonmeths.handlingtextboxes(PropertyA, testData);	
	}
	
	public static void RegisterUser(String PropertyA)throws Exception
	{
	Commonmeths.handlingClicks(PropertyA);
	}

}
