package Utilities;

public class ConstantValues {
	public static final String chromedriverexe = "D:\\selenium\\chrome driver\\chromedriver.exe";
	public static final String excelPath = "C:\\Users\\SONY\\Documents\\deeksha working\\EdurekaProject\\TestData.xlsx";
	public static final String propertiesfile = "C:\\Users\\SONY\\Documents\\deeksha working\\EdurekaProject\\locators.properties";
	//public static final String screenshotpath = "C:\\Important\\teaching\\com.Hybriddrivenframework.edureka\\evidences\\";
	
	//public static final String browserType = excelReadwrite.readStringValues("TestData", 1, 5);
	public static final String websiteURL = excelReadwrite.readStringValues("TestData", 2, 5);
	public static final String FirstName = excelReadwrite.readStringValues("TestData", 4, 5);
	public static final String LastName = excelReadwrite.readStringValues("TestData", 5, 5);
	public static final int Phone = excelReadwrite.readIntegerValues("TestData", 6, 5);
	public static final String Email = excelReadwrite.readStringValues("TestData", 7, 5);
	public static final String Address = excelReadwrite.readStringValues("TestData", 8, 5);
	public static final String City = excelReadwrite.readStringValues("TestData", 9, 5);
	public static final String State = excelReadwrite.readStringValues("TestData", 10, 5);
	public static final int zipCode = excelReadwrite.readIntegerValues("TestData", 11, 5);
	public static final String Country = excelReadwrite.readStringValues("TestData", 12, 5);
	public static final String UserName = excelReadwrite.readStringValues("TestData", 13, 5);
	public static final String RegisterPassword = excelReadwrite.readStringValues("TestData", 14, 5);
	public static final String ConfirmPassword = excelReadwrite.readStringValues("TestData", 15, 5);
	
	public static final String SignUsername = excelReadwrite.readStringValues("TestData", 18, 5);
	public static final String Password = excelReadwrite.readStringValues("TestData", 19, 5);
	public static final int NoOfPassenger = excelReadwrite.readIntegerValues("TestData", 23, 5);
	public static final String DepartFrom = excelReadwrite.readStringValues("TestData", 24, 5);
	public static final String DepartMonth = excelReadwrite.readStringValues("TestData", 25, 5);
	public static final int DepartDate = excelReadwrite.readIntegerValues("TestData", 26, 5);
	public static final String ArriveCity = excelReadwrite.readStringValues("TestData", 27, 5);
	public static final String ReturnMonth = excelReadwrite.readStringValues("TestData", 28, 5);
	public static final int ReturnDate = excelReadwrite.readIntegerValues("TestData", 29, 5);
	
	
	public static final String Fname= excelReadwrite.readStringValues("TestData", 35, 5);
	public static final String Lname= excelReadwrite.readStringValues("TestData", 36, 5);
	public static final String meal= excelReadwrite.readStringValues("TestData", 37, 5);
	public static final String cardType= excelReadwrite.readStringValues("TestData", 38, 5);
	public static final int cardNumber= excelReadwrite.readIntegerValues("TestData", 39, 5);
	public static final int ExpMonth= excelReadwrite.readIntegerValues("TestData", 40, 5);
	public static final int ExpYear= excelReadwrite.readIntegerValues("TestData", 41, 5);
	public static final String BillFirstName= excelReadwrite.readStringValues("TestData", 42, 5);
	public static final String BillLastName= excelReadwrite.readStringValues("TestData", 43, 5);
	public static final String BillAddress= excelReadwrite.readStringValues("TestData", 44, 5);
	public static final String BilCity= excelReadwrite.readStringValues("TestData", 45, 5);
	public static final String BilState= excelReadwrite.readStringValues("TestData", 46, 5);
	public static final int BilzipCode= excelReadwrite.readIntegerValues("TestData", 47, 5);
	public static final String BilCountry= excelReadwrite.readStringValues("TestData", 48, 5);
	public static final String DelAddress= excelReadwrite.readStringValues("TestData", 49, 5);
	public static final String DelCity= excelReadwrite.readStringValues("TestData", 50, 5);
	public static final String Delstate= excelReadwrite.readStringValues("TestData", 51, 5);
	public static final int Delzipcode= excelReadwrite.readIntegerValues("TestData", 52, 5);
	public static final String DelCountry= excelReadwrite.readStringValues("TestData", 53, 5);
	public static final String GmaiUrl = excelReadwrite.readStringValues("TestData", 55, 5);
	public static final String EmailOrPhone=excelReadwrite.readStringValues("TestData", 56, 5);
	public static final String GmailPassword=excelReadwrite.readStringValues("TestData", 58, 5);
	public static final String To=excelReadwrite.readStringValues("TestData", 64, 5);
	public static final String Subject=excelReadwrite.readStringValues("TestData", 65, 5);
	}
